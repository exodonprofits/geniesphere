import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles, Wallet, Plane, Salad, Mail, Calendar, Bot } from "lucide-react";

const agents = [
  {
    name: "Insurance Checker",
    description: "Analyze all your policies for savings.",
    icon: <Wallet className="h-6 w-6" />, 
    link: "https://insurance.geniesphere.com"
  },
  {
    name: "Travel Planner",
    description: "Plan trips effortlessly with AI.",
    icon: <Plane className="h-6 w-6" />,
    link: "https://travel.geniesphere.com"
  },
  {
    name: "LunchBox Planner",
    description: "Smart lunch plans for your kids.",
    icon: <Salad className="h-6 w-6" />,
    link: "https://lunchbox.geniesphere.com"
  },
  {
    name: "Gmail Sorter",
    description: "Auto-label and reply to important emails.",
    icon: <Mail className="h-6 w-6" />,
    link: "https://mail.geniesphere.com"
  },
  {
    name: "Stock Tracker",
    description: "Analyze daily market data & alerts.",
    icon: <Sparkles className="h-6 w-6" />,
    link: "https://stocks.geniesphere.com"
  },
  {
    name: "Payroll Automation",
    description: "Generate payments for W2 and 1099 staff.",
    icon: <Calendar className="h-6 w-6" />,
    link: "https://payroll.geniesphere.com"
  },
  {
    name: "Reception AI",
    description: "Answer calls & book appointments automatically.",
    icon: <Bot className="h-6 w-6" />,
    link: "https://reception.geniesphere.com"
  }
];

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-emerald-50 p-6">
      <h1 className="text-4xl font-bold text-center text-emerald-900 mb-8">GenieSphere Dashboard</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {agents.map((agent, index) => (
          <Card key={index} className="hover:shadow-xl transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-4 text-emerald-800">
                {agent.icon}
                <h2 className="text-xl font-semibold">{agent.name}</h2>
              </div>
              <p className="text-sm text-gray-600 mb-4">{agent.description}</p>
              <Button variant="outline" className="w-full" onClick={() => window.open(agent.link, '_blank')}>
                Open Agent
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}