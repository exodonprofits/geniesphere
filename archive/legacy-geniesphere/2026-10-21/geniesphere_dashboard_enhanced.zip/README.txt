GenieSphere dashboard enhancement

Upload the six HTML files to /dashboard/ on your server.
The logo must already exist at /shared/assets/logo/geniesphere_logo.png.
Original scripts, navigation routes, and data handling have been retained.
Changes: consistent header logo, titles, favicon, keyboard focus, mobile and reduced-motion polish.
No live server or functional end-to-end testing performed.
